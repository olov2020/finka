export type ReminderItemProps = {
  id?: number;
  name: string;
  price: string;
  date: string;
  link: string;
  time?: string,
};
