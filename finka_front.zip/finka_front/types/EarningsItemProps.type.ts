export type EarningsItemProps = {
  id?: number;
  name: string;
  earning: string;
  date: string;
  time?: string,
};
