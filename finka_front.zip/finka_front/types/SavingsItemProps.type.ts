export type SavingsItemProps = {
  id?: number;
  name: string;
  saving: string;
  date: string;
  time?: string,
};
