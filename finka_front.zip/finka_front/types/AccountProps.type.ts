export type AccountProps = {
  name: string,
  surname: string,
  email: string,
}