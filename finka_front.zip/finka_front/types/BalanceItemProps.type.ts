export type BalanceItemProps = {
  id?: number;
  name: string;
  balance: string;
  start_date: string;
  end_date: string;
  time?: string,
};
