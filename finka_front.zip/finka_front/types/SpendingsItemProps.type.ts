export type SpendingsItemProps = {
    id?: number;
    name: string;
    price: string;
    date: string;
    category: string;
    time?: string,
};
