import {StyleSheet} from "react-native";

export const themedTextStyle = StyleSheet.create({
    text: {
        alignSelf: 'center',
    }
});
